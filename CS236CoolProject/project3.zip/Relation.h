//
// Created by pearlhulbert on 10/23/21.
//

#ifndef CS236COOLPROJECT_RELATION_H
#define CS236COOLPROJECT_RELATION_H
#include <iostream>
#include <set>
#include <string>
#include "Header.h"
#include "Tuple.h"

class Relation {
private:
    std::string name;
    Header* attributes;
    std::set<Tuple> tuples;
public:
    Relation() {}
    Relation(std::string rName, Header* rHeader) {
        name = rName;
        attributes = rHeader;
    }
    ~Relation() {
    }

    std::string getName() const {
        return name;
    }

    void setHeader(Header* head) {
        attributes = head;
    }

    void addTuple(Tuple tup) {
        tuples.insert(tup);
    }

    size_t size() {
        return tuples.size();
    }

    Relation* selectType1(int column, std::string value) {
        Relation* newRelation = new Relation(name, attributes);
        std::vector<std::string> newValues;
        for (Tuple tul : tuples) {
                if (tul.at(column) == value) {
                    newRelation->addTuple(tul);
                }
        }
        return newRelation;
    }

    Relation* selectType2(int column1, int column2) {
        Relation* newRelation = new Relation(name, attributes);
        Tuple newTuple;
        std::vector<std::string> newAttributes;
        std::vector<std::string> newValues;
        for (Tuple tul : tuples) {
            if (tul.at(column1) == tul.at(column2)) {
                newRelation->addTuple(tul);
            }
        }
        return newRelation;
    }

    Relation* project(std::vector<int> keepColumns) {
        Header* newHeader;
        Relation* newRelation = new Relation(name, attributes);
        Tuple newTuple;
        std::vector<std::string> newAttributes;
        std::vector<std::string> newValues;
        for (size_t i = 0; i < keepColumns.size(); ++i) {
            newAttributes.push_back(attributes->at(keepColumns.at(i)));
        }
        for (Tuple tul : tuples) {
            for (size_t i = 0; i < keepColumns.size(); ++i) {
                newValues.push_back(tul.at(keepColumns.at(i)));
            }
            newTuple = Tuple(newValues);
            newRelation->addTuple(newTuple);
            newValues.clear();
        }
        newHeader = new Header(newAttributes);
        newRelation->setHeader(newHeader);
        return newRelation;
    }

    Relation* rename(std::vector<std::string> newAttributes) {
        Header* newHeader;
        Relation* newRelation;
        std::vector<std::string> newValues;
        Tuple newTuple;
        newHeader = new Header(newAttributes);
        newRelation = new Relation(name, newHeader);
        //copy tuples over
        for (Tuple tul : tuples) {
            for (size_t i = 0; i < newAttributes.size(); ++i) {
               newValues.push_back(tul.at(i));
            }
            newTuple = Tuple(newValues);
            newRelation->addTuple(newTuple);
            newValues.clear();
        }
        return newRelation;
    }

    bool empty() {
        if (tuples.empty()) {
            return true;
        }
        return false;
    }

    std::string toString() const {
        std::stringstream ss;
        for (Tuple tul : tuples) {
            for (size_t i = 0; i < attributes->size(); ++i) {
                if (i == attributes->size() - 1) {
                    ss << attributes->at(i) << "=" << tul.at(i) << std::endl;
                }
                else {
                    ss << attributes->at(i) << "=" << tul.at(i) << ", ";
                }
            }
        }
        return ss.str();
    }

    friend std::ostream& operator<<(std::ostream& os,  const Relation &rel)
    {
        return os << rel.toString();
    }
};

#endif //CS236COOLPROJECT_RELATION_H
