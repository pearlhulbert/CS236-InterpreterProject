//
// Created by pearlhulbert on 10/23/21.
//

#ifndef CS236COOLPROJECT_INTERPRETER_H
#define CS236COOLPROJECT_INTERPRETER_H
#include <iostream>
#include <string>
#include <map>
#include "Database.h"
#include "DatalogProgram.h"
#include "Relation.h"

class Interpreter {
private:
    DataLogProgram* datalog;
    Database dBase;
public:
    Interpreter() {}
    Interpreter(DataLogProgram* data) {
        datalog = data;
    }
    ~Interpreter() {
    }


    void interpret() {
        std::vector<Predicate*> schemes = datalog->getSchemes();
        std::vector<Predicate*> facts = datalog->getFacts();
        std::vector<Predicate*> queries = datalog->getQueries();
        for (Predicate* schemePred : schemes) {
            std::string relationName = schemePred->getName();
            std::vector<std::string> relationHeaderVector = schemePred->getBody();
            Header* relationHeader = new Header(relationHeaderVector);
            Relation* currRelation = new Relation(relationName, relationHeader);
            if (schemePred == schemes.front()) {
                dBase = Database(relationName, currRelation);
            }
            else {
                dBase.insert(relationName, currRelation);
            }
        }
        for (Predicate* factsPred : facts) {
            std::string relName = factsPred->getName();
            std::vector<std::string> relationTupleVector = factsPred->getBody();
            Tuple relationTuple = Tuple(relationTupleVector);
            Relation* nextRelation;
            nextRelation = dBase.matchRelation(relName);
            nextRelation->addTuple(relationTuple);
            //std::cout << nextRelation->toString();
        }
        for (Predicate* queryPred : queries) {
            std::cout << queryPred->toString() << "?";
            Relation* newRelation = evaluatePredicate(*queryPred);
            if (!newRelation->empty()) {
                std::cout << " Yes(" << newRelation->size() << ")\n" << newRelation->toString();
            }
            else {
                std::cout << " No" << std::endl;
            }
        }
    }

    Relation* evaluatePredicate(const Predicate &p) {
        std::map<std::string, int> selectMapT2;
        std::vector<int> indices;
        std::vector<std::string> values;
        Relation* currRelation = dBase.matchRelation(p.getName());
        std::vector<std::string> parameters;
        parameters = p.getBody();
        for (size_t i = 0; i < parameters.size(); ++i) {
            if (parameters.at(i).front() == '\'') {
               currRelation = currRelation->selectType1(i, parameters.at(i));
            }
            else if (parameters.at(i) == selectMapT2.find(parameters.at(i))->first) {
                currRelation = currRelation->selectType2(i, selectMapT2.find(parameters.at(i))->second);
            }
            else {
                selectMapT2.insert(std::pair<std::string, int>(parameters.at(i), i));
                indices.push_back(i);
                values.push_back(parameters.at(i));
            }
        }
        currRelation = currRelation->project(indices);
        currRelation = currRelation->rename(values);
        return currRelation;
    }

    /*std::string toString() const {
        std::stringstream ss;
        ss << dBase.toString();
        return ss.str();
    }

    friend std::ostream& operator<<(std::ostream& os,  const Interpreter &inter)
    {
        return os << inter.toString();
    }*/
};

#endif //CS236COOLPROJECT_INTERPRETER_H
