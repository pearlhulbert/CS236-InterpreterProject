//
// Created by pearlhulbert on 10/23/21.
//

#ifndef CS236COOLPROJECT_INTERPRETER_H
#define CS236COOLPROJECT_INTERPRETER_H
#include <iostream>
#include <string>
#include <map>
#include "Database.h"
#include "DatalogProgram.h"
#include "Relation.h"

class Interpreter {
private:
    DataLogProgram* datalog;
    Database dBase;
public:
    Interpreter() {}
    Interpreter(DataLogProgram* data) {
        datalog = data;
    }
    ~Interpreter() {
    }


    void interpret() {
        std::vector<Predicate*> schemes = datalog->getSchemes();
        std::vector<Predicate*> facts = datalog->getFacts();
        std::vector<Predicate*> queries = datalog->getQueries();
        std::vector<Rule*> rules = datalog->getRules();
        int tuplesAdded = 0;
        for (Predicate* schemePred : schemes) {
            std::string relationName = schemePred->getName();
            std::vector<std::string> relationHeaderVector = schemePred->getBody();
            Header* relationHeader = new Header(relationHeaderVector);
            Relation* currRelation = new Relation(relationName, relationHeader);
            if (schemePred == schemes.front()) {
                dBase = Database(relationName, currRelation);
            }
            else {
                dBase.insert(relationName, currRelation);
            }
        }
        for (Predicate* factsPred : facts) {
            std::string relName = factsPred->getName();
            std::vector<std::string> relationTupleVector = factsPred->getBody();
            Tuple relationTuple = Tuple(relationTupleVector);
            Relation* nextRelation;
            nextRelation = dBase.matchRelation(relName);
            nextRelation->addTuple(relationTuple);
        }
        int passNum = 1;
        std::cout << "Rule Evaluation" << std::endl;
        Rule* lastRule = rules.at(rules.size()-1);
        Rule* currRule = rules.at(0);
        //bool printEmpty = false;
        //bool currPrintedEmpty = false;
        do {
            for (Rule* rule : rules) {
                currRule = rule;
                Predicate* ruleHead = rule->getHead();
                Relation* headRule = evaluatePredicate(*ruleHead);
                Relation* unionRelation = dBase.matchRelation(headRule->getName());
                std::vector<Predicate*> ruleBody = rule->getRuleBody();
                std::vector<Relation*> evalRelations;
                for (Predicate* ruleBod: ruleBody) {
                    Relation* newRelation = evaluatePredicate(*ruleBod);
                    evalRelations.push_back(newRelation);
                }
                Relation* currRelation = joinRules(evalRelations, headRule->getName());
                //std::cout << "After Join: " << currRelation->toString();
                std::vector<int> keepColumns = getProjectIndices(currRelation, headRule);
                currRelation = currRelation->project(keepColumns);
                std::vector<std::string> newAttributes = dBase.matchRelation(headRule->getName())->getHeader()->getAttributes();
                currRelation = currRelation->rename(newAttributes);
                unionRelation->makeUnion(currRelation);
                tuplesAdded = unionRelation->newTupleNum();
                if (tuplesAdded == 0) {
                    if (currRule == lastRule) {
                        std::cout << rule->toString() << "." << std::endl;
                        rule->setPrintCondition(true);
                        break;
                    }
                    else {
                        std::cout << rule->toString() << "." << std::endl;
                        rule->setPrintCondition(true);
                        continue;
                    }
                }
                else {
                    std::cout << rule->toString() << ".";
                    rule->setPrintCondition(false);
                    std::cout << std::endl << unionRelation->addedToString();
                }
                dBase.setDBRelation(unionRelation->getName(), unionRelation);
            }
            if (tuplesAdded != 0) {
                ++passNum;
            }
            else if (printAll(rules)) {
                for (Rule *rule: rules) {
                    if (rule == rules.at(0)) {
                        std::cout << rule->toString() << ".";
                    }
                    else {
                        std::cout << std::endl << rule->toString() << ".";
                    }
                }
                ++passNum;
                std::cout << std::endl;
            }
        }
        while (tuplesAdded != 0 || currRule != lastRule);
        std::cout << std::endl << "Schemes populated after " << passNum << " passes through the Rules." << std::endl << std::endl;
        std::cout << "Query Evaluation" << std::endl;
        for (Predicate* queryPred : queries) {
            std::cout << queryPred->toString() << "?";
            Relation* newRelation = evaluatePredicate(*queryPred);
            if (!newRelation->empty()) {
                std::cout << " Yes(" << newRelation->size() << ")\n" << newRelation->toString();
            }
            else {
                std::cout << " No" << std::endl;
            }
        }
    }

    Relation* evaluatePredicate(const Predicate &p) {
        std::map<std::string, int> selectMapT2;
        std::vector<int> indices;
        std::vector<std::string> values;
        Relation* currRelation = dBase.matchRelation(p.getName());
        std::vector<std::string> parameters;
        parameters = p.getBody();
        for (size_t i = 0; i < parameters.size(); ++i) {
            if (parameters.at(i).front() == '\'') {
               currRelation = currRelation->selectType1(i, parameters.at(i));
            }
            else if (parameters.at(i) == selectMapT2.find(parameters.at(i))->first) {
                currRelation = currRelation->selectType2(i, selectMapT2.find(parameters.at(i))->second);
            }
            else {
                selectMapT2.insert(std::pair<std::string, int>(parameters.at(i), i));
                indices.push_back(i);
                values.push_back(parameters.at(i));
            }
        }
        currRelation = currRelation->project(indices);
        currRelation = currRelation->rename(values);
        return currRelation;
    }

    Relation* joinRules(std::vector<Relation*> ruleRelations, std::string name) {
        Relation* ruleRelation = ruleRelations.at(0);
        for (size_t i = 0; i < ruleRelations.size(); ++i) {
            if (i != ruleRelations.size() - 1) {
                //std::cout << "Rel " << i << " Before Join:\n" << ruleRelations.at(i)->toString();
                //std::cout << "Rel " << i + 1 << " Before Join:\n" << ruleRelations.at(i+1)->toString();
               ruleRelation = ruleRelation->naturalJoin(ruleRelations.at(i+1));
            }
            else if (ruleRelations.size() == 1) {
                //std::cout << "Rel 1 Before Join:\n" << ruleRelations.at(i)->toString();
                ruleRelation->setTuples(ruleRelations.at(i)->getTuples());
            }
            else {
                break;
            }
        }
        ruleRelation->setName(name);
        return ruleRelation;
    }

    std::vector<int> getProjectIndices(Relation* currRel, Relation* ruleHead) {
        std::vector<std::string> currRelAttributes = currRel->getHeader()->getAttributes();
        std::vector<std::string> ruleHeadAttributes = ruleHead->getHeader()->getAttributes();
        std::vector<int> keepColumns;
        for (size_t i = 0; i < ruleHeadAttributes.size(); ++i) {
            for (size_t j = 0; j < currRelAttributes.size(); ++j) {
                if (ruleHeadAttributes.at(i) == currRelAttributes.at(j)) {
                    keepColumns.push_back(j);
                }
            }
        }
        return keepColumns;
    }

    bool printAll(std::vector<Rule*> rules) {
        int fullRules = 0;
        for (Rule* rule : rules) {
            if (!rule->getPrintCondition()) {
                ++fullRules;
            }
        }
        if (fullRules > 0) {
            return true;
        }
        return false;
    }

};

#endif //CS236COOLPROJECT_INTERPRETER_H
